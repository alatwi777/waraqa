function isWaraqaPage(url) {
 try { const u=new URL(url);return (u.origin==='https://alatwi777.github.io'&&u.pathname.startsWith('/waraqa/'))||(u.origin==='http://127.0.0.1:18791'&&u.pathname.startsWith('/')); } catch {return false;}
}
chrome.action.onClicked.addListener((tab) => {
  if (!tab.id || !tab.url || !tab.url.startsWith("https://noor.moe.gov.sa/")) return;
  chrome.tabs.sendMessage(tab.id, { type: "OPEN_NOOR_GRADE_TOOL" });
});

chrome.runtime.onMessage.addListener((request, sender, reply) => {
  if (request?.type === "NOOR_GET_SOURCES" && sender.frameId === 0 &&
      sender.url?.startsWith("https://noor.moe.gov.sa/")) {
    chrome.storage.local.get("waraqaSources").then(data => reply(data.waraqaSources || []), () => reply([]));
    return true;
  }
  if (request?.type === "NOOR_SAVE_SOURCES" && sender.frameId === 0 &&
      isWaraqaPage(sender.url)) {
    const sources = request.sources;
    if (!Array.isArray(sources) || sources.length > 500 || !sources.every(source =>
      typeof source?.label === "string" && source.label.length <= 500 && Array.isArray(source.rows) &&
      source.rows.length <= 1000 && source.rows.every(row => typeof row?.id === "string" &&
        row.id.length <= 100 && (row.score === null || Number.isFinite(row.score)) &&
        typeof row.name === "string" && typeof row.ready === "boolean" && typeof row.status === "string"))) {
      reply({error: "تعذر تجهيز مصادر الدرجات."});
      return;
    }
    chrome.storage.local.set({waraqaSources: sources}).then(() => reply({ok: true}), () => reply({error: "تعذر تخزين المصادر لهذه الجلسة."}));
    return true;
  }
  if (request?.type !== "NOOR_PREVIEW_FROM_WARAQA" || sender.frameId !== 0 ||
      !isWaraqaPage(sender.url)) return;

  openNoorPreview(request.rows).then(reply, () => reply({
    error: "تعذر الوصول إلى كشف نور. حدّث تبويب نور ثم حاول مرة أخرى."
  }));
  return true;
});

async function openNoorPreview(rows) {
  if (!Array.isArray(rows) || !rows.length || rows.length > 1000 ||
      rows.some((row) => !row || typeof row.id !== "string" || !/^\d{1,30}$/.test(row.id) ||
        !Number.isFinite(row.score) || row.score < 0) ||
      new Set(rows.map((row) => row.id)).size !== rows.length) {
    return { error: "تعذر إرسال الدرجات. راجع أرقام الطلاب والدرجات المكررة." };
  }

  const tabs = await chrome.tabs.query({ url: "https://noor.moe.gov.sa/*" });
  const checks = await Promise.all(tabs.map(async (tab) => {
    try {
      const result = await chrome.tabs.sendMessage(tab.id, { type: "NOOR_CHECK_GRADE_TABLE" }, { frameId: 0 });
      return result?.ready ? tab : null;
    } catch {
      return null;
    }
  }));
  const candidates = checks.filter(Boolean);
  if (!candidates.length) return { error: "افتح كشف رصد الدرجات في نور وحدّثه، ثم أعد المحاولة." };
  if (candidates.length > 1) return { error: "أبقِ كشف نور المطلوب وحده مفتوحًا، ثم أعد المحاولة." };

  const [tab] = candidates;
  const result = await chrome.tabs.sendMessage(tab.id, { type: "NOOR_STAGE_WARAQA_GRADES", rows }, { frameId: 0 });
  if (!result?.ready) return { error: "تغيّر كشف الدرجات في نور. افتح الكشف المطلوب وأعد المحاولة." };
  await chrome.tabs.update(tab.id, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true });
  return { ok: true };
}
