window.addEventListener("message", async (event) => {
  const request = event.data;
  if (event.source !== window || event.origin !== location.origin ||
      !["WARAQA_NOOR_PREVIEW", "WARAQA_NOOR_SOURCES"].includes(request?.type) || typeof request.id !== "string") return;

  let result;
  try {
    result = await chrome.runtime.sendMessage({ ...request, type: request.type === "WARAQA_NOOR_SOURCES" ? "NOOR_SAVE_SOURCES" : "NOOR_PREVIEW_FROM_WARAQA" });
  } catch {
    result = { error: "تعذر الاتصال بإضافة نور. حدّث تبويبي ورقة ونور." };
  }
  window.postMessage({ type: "WARAQA_NOOR_REPLY", id: request.id, result }, location.origin);
});

function requestSources() {
  window.dispatchEvent(new Event("waraqa-noor-request-sources"));
}
if (document.readyState === "loading") window.addEventListener("DOMContentLoaded", requestSources, {once:true});
else requestSources();
