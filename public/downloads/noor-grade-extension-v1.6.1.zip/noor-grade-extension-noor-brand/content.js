(() => {
  if (window.__noorExcelGraderInstalled) return;
  window.__noorExcelGraderInstalled = true;

  const launcher = document.createElement("button");
  launcher.type = "button";
  const badge = document.createElement("span");
  const logo = document.createElement("img");
  const label = document.createElement("span");
  label.textContent = "رصد من موقع ورقة";
  logo.src = chrome.runtime.getURL("assets/waraqa-mark.png");
  logo.alt = "";
  Object.assign(badge.style, {
    display: "grid", placeItems: "center", flex: "0 0 34px",
    width: "34px", height: "34px", borderRadius: "9px", background: "#075949"
  });
  Object.assign(logo.style, {
    display: "block", width: "25px", height: "21px", objectFit: "contain",
    filter: "grayscale(1) sepia(.2) hue-rotate(105deg) brightness(1.5)",
    mixBlendMode: "screen"
  });
  badge.appendChild(logo);
  launcher.append(badge, label);
  Object.assign(launcher.style, {
    position: "fixed", insetInlineStart: "18px", bottom: "20px", zIndex: "2147483646",
    display: "inline-flex", alignItems: "center", gap: "10px",
    border: "1px solid #086b58", borderRadius: "14px", padding: "7px 9px 7px 16px",
    background: "#087f69", color: "#fff", font: "700 15px/1.4 system-ui, sans-serif",
    boxShadow: "0 5px 16px #07594945", cursor: "pointer", direction: "rtl"
  });
  document.documentElement.appendChild(launcher);

  const host = document.createElement("div");
  host.style.position = "fixed";
  host.style.inset = "0";
  host.style.zIndex = "2147483647";
  host.style.display = "none";
  document.documentElement.appendChild(host);
  const shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; }
      .shade { position:fixed; inset:0; background:#07111dcc; display:flex; align-items:center; justify-content:center; padding:18px; direction:rtl; font:14px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif; color:#172b27; }
      .panel { width:min(920px,100%); max-height:min(92vh,900px); overflow:auto; background:#fff; border:1px solid #d7e6df; border-radius:18px; box-shadow:0 24px 80px #0006; }
      .head { position:sticky; top:0; z-index:2; display:flex; align-items:center; justify-content:space-between; gap:12px; padding:16px 20px; background:#f6fbf8; border-bottom:1px solid #dceae4; }
      h2 { margin:0; font-size:19px; } .close { border:0; border-radius:50%; width:36px;height:36px;background:#e7f0eb;color:#25453d;font-size:22px;cursor:pointer; }
      .body { padding:18px 20px 22px; } .note { margin:0 0 16px; padding:11px 13px; background:#eef8f0; border:1px solid #d4ead5; border-radius:10px; color:#335b3d; }
      .grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:12px; }
      label { display:flex; flex-direction:column; gap:6px; color:#334b44; font-weight:600; }
      input[type=file], input[type=number], select { width:100%; min-height:42px; border:1px solid #cfddd7; border-radius:9px; padding:8px 10px; background:white; color:#172b27; font:inherit; }
      .filebox { grid-column:1/-1; padding:12px; border:1px dashed #a9c5b8; background:#fbfdfc; border-radius:12px; }
      .filetools { display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap; margin-top:9px; }
      .filename { color:#08704e; font-weight:600; overflow-wrap:anywhere; }
      .actions { display:flex; flex-wrap:wrap; gap:8px; margin:14px 0; }
      button.action { border:1px solid #087f69; border-radius:9px; padding:10px 15px; background:#087f69; color:white; font:600 14px system-ui,sans-serif; cursor:pointer; }
      button.secondary { background:white; color:#087f69; } button:disabled { opacity:.5; cursor:not-allowed; }
      .status { min-height:24px; margin:8px 0; color:#4a5d56; } .status.error { color:#a72828; } .status.ok { color:#08704e; }
      .counts { display:flex; flex-wrap:wrap; gap:8px; margin:12px 0; }
      .pill { display:inline-block; padding:5px 10px; border-radius:999px; background:#eff3f1; color:#42564e; font-weight:600; }
      .pill.good { background:#e1f5e8;color:#136b40; } .pill.warn { background:#fff2d6;color:#865a00; } .pill.bad { background:#fde8e8;color:#9b2929; }
      .tablewrap { max-height:300px; overflow:auto; border:1px solid #dbe5e0; border-radius:10px; }
      table { width:100%; border-collapse:collapse; font-size:13px; } th,td { padding:8px 10px; border-bottom:1px solid #edf1ef; text-align:right; white-space:nowrap; } th { position:sticky;top:0;background:#f4f8f6; }
      .muted { color:#708078; font-weight:400; } .hidden { display:none!important; }
      @media(max-width:620px) { .shade { padding:8px; align-items:flex-start; } .panel { max-height:96vh; margin-top:2vh; } .body { padding:14px; } .grid { grid-template-columns:1fr; } .filebox { grid-column:auto; } h2 { font-size:17px; } }
    </style>
    <div class="shade" role="presentation">
      <section class="panel" role="dialog" aria-modal="true" aria-labelledby="nex-title">
        <div class="head"><h2 id="nex-title">رصد درجات من Excel</h2><button class="close" type="button" title="إغلاق">×</button></div>
        <div class="body">
          <p class="note">تتم قراءة الملف ومطابقة الطلاب داخل المتصفح. يبقى الملف محفوظًا محليًا في هذا المتصفح عند الانتقال بين صفحات نور، ويمكن حذفه من هنا. الأداة تملأ حقول نور للمراجعة؛ احفظ الدرجات من نور بعد التأكد منها.</p>
          <div class="grid">
            <label class="filebox">ملف الدرجات (.xlsx أو .csv)<input id="file" type="file" accept=".xlsx,.csv,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"><span class="filetools"><span id="file-name" class="filename">لم يتم تحميل ملف</span><button id="remove-file" class="action secondary" type="button" disabled>حذف الملف المحفوظ</button></span></label>
            <label id="sheet-label" class="hidden">ورقة العمل<select id="sheet"></select></label>
            <label>صف العناوين في الملف<input id="header-row" type="number" min="1" step="1" value="1"></label>
            <label>عمود رقم الطالب<select id="id-col" disabled><option value="">ارفع الملف أولًا</option></select></label>
            <label>عمود الدرجة<select id="score-col" disabled><option value="">ارفع الملف أولًا</option></select></label>
            <label>عمود الدرجة في نور<select id="target-col"><option value="">اضغط «فحص جدول نور» أولًا</option></select></label>
          </div>
          <div class="actions">
            <button id="scan" class="action secondary" type="button">فحص جدول نور</button>
            <button id="preview" class="action" type="button" disabled>معاينة المطابقة</button>
            <button id="apply" class="action hidden" type="button" disabled>تعبئة الدرجات</button>
          </div>
          <div id="status" class="status" role="status">افتح في نور صفحة الفصل والاختبار المراد رصدهما.</div>
          <div id="counts" class="counts"></div>
          <div id="results" class="tablewrap hidden"></div>
        </div>
      </section>
    </div>`;

  const $ = (selector) => shadow.querySelector(selector);
  const fileInput = $("#file"), sheetSelect = $("#sheet"), headerInput = $("#header-row");
  const fileNameLabel = $("#file-name"), removeFileButton = $("#remove-file");
  const idSelect = $("#id-col"), scoreSelect = $("#score-col"), targetSelect = $("#target-col");
  const status = $("#status"), counts = $("#counts"), results = $("#results"), previewButton = $("#preview"), applyButton = $("#apply");
  let book = null, currentSheetRows = [], parsedHeaders = [], previewRows = [], scanSnapshot = [], targetColumns = [];
  let tableHeaderCache = new WeakMap();
  let gradeHeaderElementCache = new WeakMap();
  const STORAGE_KEY = "noorExcelGradeWorkbookV1";
  let restoringSettings = false;
  let settingsSaveTimer = 0;

  launcher.addEventListener("click", openTool);
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "OPEN_NOOR_GRADE_TOOL") openTool();
  });
  let waraqaRows = null;
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id) return;
    if (message?.type === "NOOR_CHECK_GRADE_TABLE" || message?.type === "NOOR_STAGE_WARAQA_GRADES") {
      tableHeaderCache = new WeakMap();
      gradeHeaderElementCache = new WeakMap();
      const ready = findGradeColumns(findNoorRows()).length > 0;
      if (!ready || message.type === "NOOR_CHECK_GRADE_TABLE") { reply({ ready }); return; }
      openTool().then(() => {
        waraqaRows = message.rows;
        invalidatePreview();
        targetSelect.value = "";
        previewButton.disabled = false;
        setStatus(`وصلت ${waraqaRows.length} درجة من ورقة. تأكد من الصف والمادة والفترة، ثم اختر عمود الدرجة واضغط معاينة.`, "ok");
        reply({ ready: true });
      }, () => reply({ ready: false }));
      return true;
    }
  });
  async function openTool() { host.style.display = "block"; document.addEventListener("keydown", onKeydown); await restorePromise; scanNoor(); }
  $(".close").addEventListener("click", close);
  $(".shade").addEventListener("click", (event) => { if (event.target === $(".shade")) close(); });
  document.addEventListener("keydown", onKeydown);
  function onKeydown(event) { if (event.key === "Escape" && host.style.display !== "none") close(); }
  function close() { if (waraqaRows) { waraqaRows = null; invalidatePreview(); } host.style.display = "none"; document.removeEventListener("keydown", onKeydown); }

  $("#scan").addEventListener("click", scanNoor);
  fileInput.addEventListener("change", loadFile);
  removeFileButton.addEventListener("click", removeSavedFile);
  sheetSelect.addEventListener("change", () => { selectSheet(); persistSettings(); });
  headerInput.addEventListener("change", () => { refreshColumnChoices(); persistSettings(); });
  idSelect.addEventListener("change", () => { invalidatePreview(); persistSettings(); });
  scoreSelect.addEventListener("change", () => { invalidatePreview(); persistSettings(); });
  targetSelect.addEventListener("change", () => { invalidatePreview(); persistSettings(); });
  previewButton.addEventListener("click", makePreview);
  applyButton.addEventListener("click", applyGrades);

  const restorePromise = restoreSavedWorkbook();
  let savedTargetLabel = "";

  function setStatus(message, kind = "") { status.textContent = message; status.className = `status ${kind}`; }
  function invalidatePreview() { previewRows = []; results.classList.add("hidden"); counts.replaceChildren(); applyButton.classList.add("hidden"); }
  function colName(index) { let n = index + 1, out = ""; while (n) { const r = (n - 1) % 26; out = String.fromCharCode(65 + r) + out; n = Math.floor((n - 1) / 26); } return out; }
  function option(select, value, label) { const node = document.createElement("option"); node.value = value; node.textContent = label; select.appendChild(node); }

  function currentSavedState() {
    return {
      book,
      fileName: fileNameLabel.dataset.fileName || "",
      sheetIndex: sheetSelect.value || "0",
      headerRow: headerInput.value || "1",
      idColumn: idSelect.value,
      scoreColumn: scoreSelect.value,
      targetLabel: targetColumns[Number(targetSelect.value)]?.label || savedTargetLabel || "",
      savedAt: Date.now()
    };
  }

  async function persistWorkbook() {
    if (!book) return;
    try {
      await chrome.storage.local.set({ [STORAGE_KEY]: currentSavedState() });
      setFileLabel(fileNameLabel.dataset.fileName || "ملف Excel محفوظ محليًا", true);
      return true;
    } catch (error) {
      setFileLabel(fileNameLabel.dataset.fileName || "الملف الحالي غير محفوظ", false);
      setStatus("تم فتح الملف، لكن تعذر حفظه بين صفحات نور. جرّب ملفًا أصغر أو احذف ملفات الإضافة القديمة.", "error");
      return false;
    }
  }

  function persistSettings() {
    if (restoringSettings || !book) return;
    savedTargetLabel = targetColumns[Number(targetSelect.value)]?.label || savedTargetLabel;
    clearTimeout(settingsSaveTimer);
    settingsSaveTimer = setTimeout(persistWorkbook, 120);
  }

  function setFileLabel(name, saved) {
    fileNameLabel.dataset.fileName = name || "";
    fileNameLabel.textContent = name ? `${name}${saved ? " — محفوظ محليًا" : " — غير محفوظ"}` : "لم يتم تحميل ملف";
    removeFileButton.disabled = !book;
  }

  async function restoreSavedWorkbook() {
    restoringSettings = true;
    try {
      const stored = (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY];
      if (!stored?.book?.sheets?.length) return;
      book = stored.book;
      setFileLabel(stored.fileName || "ملف Excel", true);
      sheetSelect.replaceChildren();
      book.sheets.forEach((sheet, index) => option(sheetSelect, String(index), sheet.name));
      const sheetIndex = Math.min(Number(stored.sheetIndex || 0), book.sheets.length - 1);
      sheetSelect.value = String(sheetIndex);
      $("#sheet-label").classList.toggle("hidden", book.sheets.length < 2);
      headerInput.value = stored.headerRow || "1";
      savedTargetLabel = stored.targetLabel || "";
      selectSheet();
      if (stored.idColumn != null) idSelect.value = String(stored.idColumn);
      if (stored.scoreColumn != null) scoreSelect.value = String(stored.scoreColumn);
      setStatus(`الملف «${stored.fileName || "Excel"}» جاهز ومثبت. يمكنك متابعة رصد الصفحة الحالية.`, "ok");
    } catch (error) {
      setFileLabel("تعذر استعادة الملف المحفوظ", false);
      setStatus("تعذر استعادة ملف Excel المحفوظ. ارفع الملف مرة أخرى.", "error");
    } finally { restoringSettings = false; }
  }

  async function removeSavedFile() {
    try { await chrome.storage.local.remove(STORAGE_KEY); }
    catch (error) { setStatus("تعذر حذف الملف من التخزين المحلي في Chrome.", "error"); return; }
    book = null; currentSheetRows = []; parsedHeaders = []; previewRows = []; savedTargetLabel = "";
    fileInput.value = ""; setFileLabel("", false);
    sheetSelect.replaceChildren(); $("#sheet-label").classList.add("hidden");
    for (const select of [idSelect, scoreSelect]) { select.replaceChildren(); option(select, "", "ارفع الملف أولًا"); select.disabled = true; }
    invalidatePreview();
    setStatus("تم حذف ملف Excel المحفوظ. ارفع ملفًا جديدًا عند الحاجة.", "ok");
  }

  async function loadFile() {
    waraqaRows = null;
    invalidatePreview(); book = null;
    const file = fileInput.files?.[0]; if (!file) return;
    try {
      if (/\.csv$/i.test(file.name)) book = { sheets: [{ name: "CSV", rows: parseCsv(await file.text()) }] };
      else if (/\.xlsx$/i.test(file.name)) book = await parseXlsx(await file.arrayBuffer());
      else throw new Error("الصيغة غير مدعومة. استخدم .xlsx أو .csv؛ واحفظ ملفات .xls بصيغة .xlsx.");
      if (!book.sheets.length) throw new Error("لم أجد أوراق عمل داخل الملف.");
      sheetSelect.replaceChildren();
      book.sheets.forEach((sheet, index) => option(sheetSelect, String(index), sheet.name));
      $("#sheet-label").classList.toggle("hidden", book.sheets.length < 2);
      fileNameLabel.dataset.fileName = file.name;
      setFileLabel(file.name, false);
      selectSheet();
      const saved = await persistWorkbook();
      if (saved) setStatus(`تم فتح الملف «${file.name}» وحفظه محليًا. اختر عمود رقم الطالب وعمود الدرجة.`, "ok");
    } catch (error) { book = null; setFileLabel("", false); setStatus(error.message || "تعذر قراءة الملف.", "error"); }
  }

  function selectSheet() {
    if (!book) return;
    currentSheetRows = book.sheets[Number(sheetSelect.value || 0)]?.rows || [];
    refreshColumnChoices();
  }

  function refreshColumnChoices() {
    if (!currentSheetRows.length) return;
    const headerIndex = Math.max(0, Number(headerInput.value || 1) - 1);
    parsedHeaders = currentSheetRows[headerIndex] || [];
    const width = Math.max(parsedHeaders.length, ...currentSheetRows.slice(headerIndex + 1, headerIndex + 5).map((row) => row.length), 0);
    const oldId = idSelect.value, oldScore = scoreSelect.value;
    for (const select of [idSelect, scoreSelect]) {
      select.replaceChildren();
      option(select, "", "اختر العمود");
      for (let i = 0; i < width; i++) {
        const title = String(parsedHeaders[i] ?? "").trim();
        option(select, String(i), `${colName(i)} — ${title || `عمود ${colName(i)}`}`);
      }
      select.disabled = width === 0;
    }
    if (oldId !== "" && Number(oldId) < width) idSelect.value = oldId;
    if (oldScore !== "" && Number(oldScore) < width) scoreSelect.value = oldScore;
    // Suggest columns from common Arabic/English header names, without selecting ambiguously.
    const findHeader = (patterns) => parsedHeaders.findIndex((value) => patterns.some((pattern) => pattern.test(String(value ?? ""))));
    if (oldId === "") { const i = findHeader([/رقم/, /سجل/, /هوية/, /student\s*id/i, /id\s*number/i]); if (i >= 0) idSelect.value = String(i); }
    if (oldScore === "") { const i = findHeader([/درجة/, /نتيجة/, /score/i, /mark/i]); if (i >= 0) scoreSelect.value = String(i); }
    previewButton.disabled = width === 0;
    invalidatePreview();
  }

  function scanNoor() {
    tableHeaderCache = new WeakMap();
    gradeHeaderElementCache = new WeakMap();
    scanSnapshot = findNoorRows();
    const gradeColumns = findGradeColumns(scanSnapshot);
    targetColumns = gradeColumns;
    targetSelect.replaceChildren();
    if (!scanSnapshot.length) {
      option(targetSelect, "", "لم أجد صفوفًا بأرقام طلاب في الجدول الحالي");
      setStatus("لم أتمكن من قراءة جدول الطلاب في الصفحة. افتح جدول الرصد كاملًا ثم اضغط «فحص جدول نور».", "error");
      counts.replaceChildren(); return;
    }
    option(targetSelect, "", "اختر عمود الدرجة في نور");
    for (const col of gradeColumns) option(targetSelect, String(col.index), col.label);
    if (!gradeColumns.length) option(targetSelect, "", "لا تظهر حقول درجات قابلة للتعبئة");
    if (savedTargetLabel) {
      const remembered = gradeColumns.find((column) => column.label === savedTargetLabel);
      if (remembered) targetSelect.value = String(remembered.index);
    }
    const duplicateIds = duplicates(scanSnapshot.map((row) => row.id));
    counts.replaceChildren();
    addPill(`${scanSnapshot.length} صفًا بأرقام طلاب`, "good");
    if (duplicateIds.size) addPill(`${duplicateIds.size} أرقام مكررة في نور`, "warn");
    setStatus(gradeColumns.length ? (book ? "الملف محفوظ. اختر عمود نور ثم تابع المعاينة والتعبئة." : "اختر عمود الدرجة الصحيح في نور، ثم ارفع ملف Excel.") : "وجدت صفوف طلاب، لكن لم أتعرف على حقول الدرجات. تأكد أن خلايا الدرجة قابلة للتعديل.", gradeColumns.length ? "ok" : "error");
    if (book) persistSettings();
  }

  function findNoorRows() {
    const seen = new Set(), found = [];
    for (const rowEl of document.querySelectorAll("tr,[role='row']")) {
      const cells = Array.from(rowEl.querySelectorAll(":scope > th, :scope > td, :scope > [role='gridcell'], :scope > [role='cell']"));
      if (!cells.length) continue;
      let id = "", idCell = -1;
      for (let i = 0; i < cells.length; i++) {
        const candidate = normalizeId(cells[i].innerText || cells[i].textContent || "");
        if (candidate.length >= 8 && candidate.length <= 12) { id = candidate; idCell = i; break; }
      }
      if (!id) continue;
      // Noor rows contain several non-grade controls (attendance selects,
      // notes fields, and sometimes identity controls). Only score-like
      // numeric inputs are valid targets for grade import.
      const controls = Array.from(rowEl.querySelectorAll("input,select,textarea")).filter((control) => isScoreControl(control, rowEl));
      if (!controls.length) continue;
      const cellsForRow = cells.length ? cells : Array.from(rowEl.children);
      const candidates = controls.map((control) => {
        let cell = control.closest("td,th,[role='gridcell'],[role='cell']");
        let index = cell ? logicalCellIndex(cellsForRow, cell) : -1;
        if (index < 0) index = Array.from(rowEl.querySelectorAll("input,select,textarea")).indexOf(control);
        return { control, index };
      });
      const signature = `${id}|${rowEl.innerText || rowEl.textContent}`;
      if (seen.has(signature)) continue; seen.add(signature);
      found.push({ id, rowEl, idCell, cells: cellsForRow, candidates, text: (rowEl.innerText || rowEl.textContent || "").trim().replace(/\s+/g, " ") });
    }
    return found;
  }

  function isScoreControl(el, rowEl) {
    if (el.disabled || el.readOnly || el.type === "hidden" || ["button", "submit", "reset", "checkbox", "radio", "file", "password", "search"].includes((el.type || "").toLowerCase())) return false;
    if (el.tagName === "SELECT" || el.tagName === "TEXTAREA") return false;
    const type = (el.type || "text").toLowerCase();
    if (!["number", "text", "tel"].includes(type)) return false;
    if (isControlUnderGradeHeader(el, rowEl)) return true;
    const cell = el.closest("td,th,[role='gridcell'],[role='cell']");
    const rowCells = Array.from(rowEl.querySelectorAll(":scope > th, :scope > td, :scope > [role='gridcell'], :scope > [role='cell']"));
    const index = cell ? logicalCellIndex(rowCells, cell) : -1;
    const columnHeader = index >= 0 ? getNoorColumnHeader(rowEl, index) : "";
    if (/هوية|رقم الطالب|اسم الطالب|student\s*id|identity/i.test(columnHeader)) return false;
    if (index >= 0 && isGradeHeader(columnHeader)) return true;
    if (type === "number" && columnHeader) return false;
    // Noor renders grade boxes as numeric text inputs in some views.
    // Blank boxes are still collected when their neighboring rows establish
    // the same score column.
    return cleanScore(el.value) !== "" || /^\s*\d+(?:[.,]\d+)?\s*$/.test(el.placeholder || "");
  }

  function findGradeColumns(rows) {
    const tables = Array.from(new Set(rows.map((row) => row.rowEl.closest("table")).filter(Boolean)));
    const columns = [];
    for (const table of tables) {
      for (const header of getGradeHeaderElements(table)) {
        const matchingRows = rows.filter((row) => row.rowEl.closest("table") === table);
        const hasField = matchingRows.some((row) => row.candidates.some(({ control }) => isControlInsideHeaderColumn(control, header.element)));
        if (!hasField) continue;
        const label = header.label;
        if (columns.some((column) => column.table === table && column.label === label)) continue;
        columns.push({ index: columns.length, label, headerElement: header.element, table });
      }
    }
    return columns;
  }

  function canonicalGradeLabel(text) {
    const clean = String(text || "").replace(/\s+/g, " ").trim();
    if (/تقويمات\s*تحريرية/.test(clean)) return "تقويمات تحريرية";
    if (/المهام\s*الأدائية/.test(clean)) return "المهام الأدائية والمشاركة والتفاعل";
    return clean.slice(0, 90);
  }

  function getGradeHeaderElements(table) {
    if (gradeHeaderElementCache.has(table)) return gradeHeaderElementCache.get(table);
    const cells = Array.from(table.querySelectorAll("th,td")).filter((cell) => {
      const row = cell.closest("tr");
      if (!row || findRowId(row)) return false;
      return isGradeHeader(cell.innerText || cell.textContent || "");
    });
    // Prefer the cell carrying the printed category title over nested cells
    // that only contain a maximum-score field or attendance selector.
    const selected = [];
    for (const cell of cells) {
      const raw = cell.innerText || cell.textContent || "";
      const label = canonicalGradeLabel(raw);
      if (!label || !isGradeHeader(label)) continue;
      const rect = cell.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) continue;
      const previous = selected.find((item) => item.label === label);
      if (!previous) selected.push({ element: cell, label });
      else {
        const previousRect = previous.element.getBoundingClientRect();
        const cellContainsPrevious = cell.contains(previous.element);
        const previousContainsCell = previous.element.contains(cell);
        if ((cellContainsPrevious && !previousContainsCell) || (!previousContainsCell && rect.width > previousRect.width)) {
          previous.element = cell;
        }
      }
    }
    // The table header can have a parent cell whose text contains both grade
    // labels. Recover each exact requested label from its nearest leaf cell.
    const desired = ["تقويمات تحريرية", "المهام الأدائية والمشاركة والتفاعل"];
    for (const title of desired) {
      if (selected.some((item) => item.label === title)) continue;
      const match = cells.find((cell) => new RegExp(title === "تقويمات تحريرية" ? "تقويمات\\s*تحريرية" : "المهام\\s*الأدائية").test(cell.innerText || cell.textContent || ""));
      if (match) selected.push({ element: match, label: title });
    }
    const result = selected.filter((item, index, all) => all.findIndex((other) => other.label === item.label) === index);
    gradeHeaderElementCache.set(table, result);
    return result;
  }

  function isControlUnderGradeHeader(control, rowEl) {
    const table = rowEl.closest("table");
    if (!table) return false;
    return getGradeHeaderElements(table).some((header) => isControlInsideHeaderColumn(control, header.element));
  }

  function isControlInsideHeaderColumn(control, headerElement) {
    const controlRect = control.getBoundingClientRect();
    const headerRect = headerElement.getBoundingClientRect();
    if (!controlRect.width || !headerRect.width) return false;
    const x = controlRect.left + controlRect.width / 2;
    return x >= headerRect.left - 2 && x <= headerRect.right + 2;
  }

  function isGradeHeader(label) {
    return /درجة|درجات|تقويم|مهام|أداء|مشاركة|تفاعل|اختبار|تحريري|واجب|score|grade|assessment|mark/i.test(String(label || ""));
  }

  function logicalCellIndex(cells, target) {
    let logical = 0;
    for (const cell of cells) {
      if (cell === target) return logical;
      logical += Math.max(1, Number(cell.colSpan) || 1);
    }
    return -1;
  }

  function getNoorColumnHeader(rowEl, index) {
    const header = getNoorColumnHeaders(rowEl).find((item) => item.index === index)?.label;
    if (header) return header;
    return "";
  }

  function getNoorColumnHeaders(rowEl) {
    const table = rowEl.closest("table");
    if (table && tableHeaderCache.has(table)) return tableHeaderCache.get(table);
    let result = [];
    if (table) {
      const candidates = Array.from(table.rows).filter((row) => {
        if (findRowId(row)) return false;
        return row.cells?.length > 0;
      }).map((row) => {
        const cells = Array.from(row.cells);
        const text = row.innerText || row.textContent || "";
        const thCount = cells.filter((cell) => cell.tagName === "TH").length;
        const gradeTerms = isGradeHeader(text) ? 1 : 0;
        return { cells, thCount, length: cells.reduce((sum, cell) => sum + Math.max(1, Number(cell.colSpan) || 1), 0), gradeTerms };
      }).sort((a, b) => (b.gradeTerms - a.gradeTerms) || (b.thCount - a.thCount) || (b.length - a.length));
      for (const candidate of candidates) {
        const labels = [];
        let position = 0;
        for (const cell of candidate.cells) {
          const span = Math.max(1, Number(cell.colSpan) || 1);
          const label = (cell.innerText || cell.textContent || "").replace(/\s+/g, " ").trim();
          if (label && !/^\d+(?:[.,]\d+)?$/.test(label)) {
            for (let offset = 0; offset < span; offset++) labels.push({ index: position + offset, label: label.slice(0, 90) });
          } else {
            for (let offset = 0; offset < span; offset++) labels.push({ index: position + offset, label: "" });
          }
          position += span;
        }
        if (labels.some((item) => item.label)) { result = labels.filter((item) => item.label); break; }
      }
    }
    // ARIA grid fallback: look for column headers in the same nearest grid.
    const grid = rowEl.closest("[role='grid'],[role='table']");
    if (!result.length && grid) {
      const headers = Array.from(grid.querySelectorAll("[role='columnheader']"));
      result = headers.map((cell, index) => ({ index, label: (cell.innerText || cell.textContent || "").replace(/\s+/g, " ").trim().slice(0, 90) })).filter((item) => item.label);
    }
    if (table) tableHeaderCache.set(table, result);
    return result;
  }

  function logicalHeaderCell(cells, logicalIndex) {
    let position = 0;
    for (const cell of cells) {
      const span = Math.max(1, Number(cell.colSpan) || 1);
      if (logicalIndex >= position && logicalIndex < position + span) return cell;
      position += span;
    }
    return null;
  }

  function findRowId(row) {
    const text = row.innerText || row.textContent || "";
    const match = text.replace(/[٠-٩۰-۹]/g, (digit) => arabicDigit(digit)).match(/\d{8,12}/);
    return match?.[0] || "";
  }

  function makePreview() {
    if ((!book && !waraqaRows) || !scanSnapshot.length) { setStatus("ارفع ملف الدرجات وافحص جدول نور أولًا.", "error"); return; }
    const idIndex = Number(idSelect.value), scoreIndex = Number(scoreSelect.value), targetIndex = Number(targetSelect.value);
    if ((!waraqaRows && (idSelect.value === "" || scoreSelect.value === "" || !Number.isInteger(idIndex) || !Number.isInteger(scoreIndex))) || targetSelect.value === "" || !Number.isInteger(targetIndex)) { setStatus("اختر عمود رقم الطالب وعمود الدرجة وعمود الدرجة في نور.", "error"); return; }
    persistSettings();
    const headerIndex = Math.max(0, Number(headerInput.value || 1) - 1);
    const records = waraqaRows ? waraqaRows.map((row, i) => ({ excelRow: i + 1, id: row.id, score: String(row.score) })) : currentSheetRows.slice(headerIndex + 1).map((row, i) => ({
      excelRow: headerIndex + i + 2,
      id: normalizeId(row[idIndex]),
      score: cleanScore(row[scoreIndex]),
    })).filter((record) => record.id || record.score !== "");
    const excelById = new Map();
    records.forEach((record) => { if (!record.id) return; const list = excelById.get(record.id) || []; list.push(record); excelById.set(record.id, list); });
    const noorById = new Map();
    scanSnapshot.forEach((row) => { const list = noorById.get(row.id) || []; list.push(row); noorById.set(row.id, list); });
    const duplicateExcel = duplicates(records.map((record) => record.id).filter(Boolean));
    const duplicateNoor = duplicates(scanSnapshot.map((row) => row.id));
    previewRows = records.map((record) => {
      const excelMatches = excelById.get(record.id) || [];
      const noorMatches = noorById.get(record.id) || [];
      let result = "جاهز للتعبئة", key = "ready", target = noorMatches[0];
      if (!record.id) { result = "رقم الطالب فارغ"; key = "bad"; }
      else if (!record.score) { result = "الدرجة فارغة أو غير رقمية"; key = "bad"; }
      else if (duplicateExcel.has(record.id)) { result = "رقم مكرر في المصدر"; key = "warn"; }
      else if (duplicateNoor.has(record.id)) { result = "رقم مكرر في نور"; key = "warn"; }
      else if (!noorMatches.length) { result = "غير موجود في جدول نور الحالي"; key = "missing"; }
      else if (!targetColumns[targetIndex] || !getControlAt(target, targetColumns[targetIndex])) { result = "لم أجد حقل الدرجة بهذا العمود"; key = "bad"; }
      return { ...record, target, result, key, targetIndex, targetColumn: targetColumns[targetIndex] };
    });
    renderPreview();
  }

  function renderPreview() {
    const ready = previewRows.filter((row) => row.key === "ready").length;
    const missing = previewRows.filter((row) => row.key === "missing").length;
    const invalid = previewRows.filter((row) => row.key === "bad").length;
    const duplicatesCount = previewRows.filter((row) => row.key === "warn").length;
    counts.replaceChildren();
    addPill(`${ready} جاهز`, "good");
    if (missing) addPill(`${missing} غير موجود في نور`, "warn");
    if (duplicatesCount) addPill(`${duplicatesCount} مكرر`, "warn");
    if (invalid) addPill(`${invalid} يحتاج مراجعة`, "bad");
    const visibleRows = previewRows.slice(0, 150);
    results.innerHTML = `<table><thead><tr><th>${waraqaRows ? "ترتيب ورقة" : "صف Excel"}</th><th>رقم الطالب</th><th>الدرجة</th><th>الحالة</th></tr></thead><tbody>${visibleRows.map((row) => `<tr><td>${row.excelRow}</td><td>${escapeHtml(row.id || "—")}</td><td>${escapeHtml(row.score || "—")}</td><td>${escapeHtml(row.result)}</td></tr>`).join("")}</tbody></table>`;
    results.classList.remove("hidden");
    applyButton.classList.remove("hidden"); applyButton.disabled = ready === 0;
    setStatus(previewRows.length > 150 ? `المعاينة تعرض أول 150 صفًا من ${previewRows.length}. سيتم تعبئة الصفوف الجاهزة فقط.` : `تمت المعاينة: ${ready} درجة قابلة للتعبئة.`, ready ? "ok" : "error");
  }

  function applyGrades() {
    let applied = 0, skipped = 0;
    for (const row of previewRows) {
      if (row.key !== "ready" || !row.target || !document.contains(row.target.rowEl)) { skipped++; continue; }
      const control = getControlAt(row.target, row.targetColumn);
      if (!control || (waraqaRows && findRowId(row.target.rowEl) !== row.id)) { skipped++; row.result = "اختفى حقل الدرجة؛ أعد الفحص"; row.key = "bad"; continue; }
      const ok = setControlValue(control, row.score);
      if (ok) { applied++; row.result = "تمت التعبئة — راجع قبل الحفظ"; row.key = "applied"; }
      else { skipped++; row.result = "تعذر تعبئة الحقل"; row.key = "bad"; }
    }
    renderPreview();
    applyButton.disabled = true;
    setStatus(`تمت تعبئة ${applied} درجة. ${skipped ? `تجاوزت ${skipped} صفوف.` : ""} راجع القيم في نور واحفظها يدويًا.`, applied ? "ok" : "error");
  }

  function getControlAt(row, targetColumn) {
    if (typeof targetColumn === "number") targetColumn = targetColumns[targetColumn];
    if (!targetColumn?.headerElement) return null;
    return row.candidates.find((item) => isControlInsideHeaderColumn(item.control, targetColumn.headerElement))?.control || null;
  }
  function setControlValue(control, score) {
    if (!control || !document.contains(control)) return false;
    if (control.tagName === "SELECT") {
      const match = Array.from(control.options).find((opt) => opt.value === score || opt.textContent.trim() === score);
      if (!match) return false;
      control.value = match.value;
    } else {
      const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(control), "value")?.set;
      if (setter) setter.call(control, score); else control.value = score;
    }
    control.dispatchEvent(new Event("input", { bubbles: true }));
    control.dispatchEvent(new Event("change", { bubbles: true }));
    control.dispatchEvent(new Event("blur", { bubbles: true }));
    return String(control.value) === String(score);
  }

  function addPill(text, kind = "") { const el = document.createElement("span"); el.className = `pill ${kind}`; el.textContent = text; counts.appendChild(el); }
  function duplicates(values) { const seen = new Set(), twice = new Set(); for (const value of values) { if (!value) continue; if (seen.has(value)) twice.add(value); else seen.add(value); } return twice; }
  function arabicDigit(digit) { const digits = "٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹"; const index = digits.indexOf(digit); return index < 10 ? String(index) : String(index - 10); }
  function normalizeId(value) {
    let text = String(value ?? "").trim().replace(/[٠-٩۰-۹]/g, arabicDigit).replace(/[\u00a0\s]/g, "");
    if (/^\d+\.0+$/.test(text)) text = text.replace(/\.0+$/, "");
    return text.replace(/[^\d]/g, "");
  }
  function cleanScore(value) {
    const text = String(value ?? "").trim().replace(/[٠-٩۰-۹]/g, arabicDigit).replace(/[\u00a0\s]/g, "").replace(/٫/g, ".").replace(/٬/g, "");
    if (!text) return "";
    const number = Number(text);
    return Number.isFinite(number) ? String(number) : "";
  }
  function escapeHtml(value) { return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]); }

  function parseCsv(text) {
    text = text.replace(/^\uFEFF/, "");
    const delimiter = (text.split(/\r?\n/, 1)[0].match(/;/g) || []).length > (text.split(/\r?\n/, 1)[0].match(/,/g) || []).length ? ";" : ",";
    const rows = []; let row = [], cell = "", quoted = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (ch === '"') { if (quoted && text[i + 1] === '"') { cell += '"'; i++; } else quoted = !quoted; }
      else if (ch === delimiter && !quoted) { row.push(cell); cell = ""; }
      else if ((ch === "\n" || ch === "\r") && !quoted) { if (ch === "\r" && text[i + 1] === "\n") i++; row.push(cell); rows.push(row); row = []; cell = ""; }
      else cell += ch;
    }
    if (cell || row.length) { row.push(cell); rows.push(row); }
    return rows;
  }

  async function parseXlsx(buffer) {
    const zip = await unzip(buffer);
    const workbookXml = zip.get("xl/workbook.xml");
    const relsXml = zip.get("xl/_rels/workbook.xml.rels");
    if (!workbookXml || !relsXml) throw new Error("الملف لا يبدو كملف Excel .xlsx صالح.");
    const workbook = xmlDoc(workbookXml), rels = xmlDoc(relsXml);
    const relationshipMap = new Map(Array.from(rels.getElementsByTagName("Relationship")).map((el) => [el.getAttribute("Id"), el.getAttribute("Target")]));
    const sharedXml = zip.get("xl/sharedStrings.xml");
    const shared = sharedXml ? Array.from(xmlDoc(sharedXml).getElementsByTagName("si")).map((si) => Array.from(si.getElementsByTagName("t")).map((t) => t.textContent).join("")) : [];
    const sheets = [];
    for (const sheet of Array.from(workbook.getElementsByTagName("sheet"))) {
      const relId = sheet.getAttribute("r:id") || sheet.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
      const target = relationshipMap.get(relId); if (!target) continue;
      const path = normalizeZipPath(target.startsWith("/") ? target.slice(1) : `xl/${target}`);
      const xml = zip.get(path); if (!xml) continue;
      sheets.push({ name: sheet.getAttribute("name") || `ورقة ${sheets.length + 1}`, rows: sheetRows(xmlDoc(xml), shared) });
    }
    return { sheets };
  }

  function xmlDoc(text) { return new DOMParser().parseFromString(text, "application/xml"); }
  function sheetRows(doc, shared) {
    const rows = [];
    for (const rowEl of Array.from(doc.getElementsByTagName("row"))) {
      const rowNumber = Number(rowEl.getAttribute("r")) || rows.length + 1;
      const row = rows[rowNumber - 1] || (rows[rowNumber - 1] = []);
      for (const cell of Array.from(rowEl.getElementsByTagName("c"))) {
        const ref = cell.getAttribute("r") || "A1", letters = (ref.match(/^[A-Z]+/i) || ["A"])[0].toUpperCase();
        let column = 0; for (const letter of letters) column = column * 26 + letter.charCodeAt(0) - 64; column--;
        const type = cell.getAttribute("t"), valueEl = cell.getElementsByTagName("v")[0];
        let value = valueEl?.textContent ?? "";
        if (type === "s") value = shared[Number(value)] ?? "";
        else if (type === "inlineStr") value = Array.from(cell.getElementsByTagName("t")).map((t) => t.textContent).join("");
        else if (type === "b") value = value === "1" ? "TRUE" : "FALSE";
        row[column] = value;
      }
    }
    return rows.map((row) => row || []);
  }

  function normalizeZipPath(path) {
    const parts = [];
    for (const part of path.replace(/\\/g, "/").split("/")) { if (!part || part === ".") continue; if (part === "..") parts.pop(); else parts.push(part); }
    return parts.join("/");
  }

  async function unzip(buffer) {
    const bytes = new Uint8Array(buffer), view = new DataView(buffer), decoder = new TextDecoder();
    let eocd = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) if (view.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    if (eocd < 0) throw new Error("تعذر قراءة حاوية ملف Excel.");
    const entries = view.getUint16(eocd + 10, true), directoryOffset = view.getUint32(eocd + 16, true);
    const output = new Map(); let cursor = directoryOffset;
    for (let i = 0; i < entries; i++) {
      if (view.getUint32(cursor, true) !== 0x02014b50) throw new Error("تنسيق ضغط ملف Excel غير مدعوم.");
      const method = view.getUint16(cursor + 10, true), compressedSize = view.getUint32(cursor + 20, true);
      const nameLength = view.getUint16(cursor + 28, true), extraLength = view.getUint16(cursor + 30, true), commentLength = view.getUint16(cursor + 32, true);
      const localOffset = view.getUint32(cursor + 42, true), name = decoder.decode(bytes.subarray(cursor + 46, cursor + 46 + nameLength));
      cursor += 46 + nameLength + extraLength + commentLength;
      if (name.endsWith("/")) continue;
      if (view.getUint32(localOffset, true) !== 0x04034b50) continue;
      const localNameLength = view.getUint16(localOffset + 26, true), localExtraLength = view.getUint16(localOffset + 28, true);
      const dataStart = localOffset + 30 + localNameLength + localExtraLength;
      const compressed = bytes.slice(dataStart, dataStart + compressedSize);
      let data;
      if (method === 0) data = compressed;
      else if (method === 8) {
        if (typeof DecompressionStream === "undefined") throw new Error("إصدار Chrome لا يدعم فك ضغط ملف Excel؛ حدّث Chrome ثم أعد المحاولة.");
        const stream = new Blob([compressed]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
        data = new Uint8Array(await new Response(stream).arrayBuffer());
      } else continue;
      output.set(normalizeZipPath(name), decoder.decode(data));
    }
    return output;
  }
})();
