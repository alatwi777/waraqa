chrome.action.onClicked.addListener((tab) => {
  if (!tab.id || !tab.url || !tab.url.startsWith("https://noor.moe.gov.sa/")) return;
  chrome.tabs.sendMessage(tab.id, { type: "OPEN_NOOR_GRADE_TOOL" });
});

chrome.runtime.onMessage.addListener((request, sender, reply) => {
  if (request?.type !== "NOOR_PREVIEW_FROM_WARAQA" || sender.frameId !== 0 ||
      !sender.url?.startsWith("https://alatwi777.github.io/waraqa/")) return;

  openNoorPreview(request.rows).then(reply, () => reply({
    error: "تعذر الوصول إلى كشف نور. حدّث تبويب نور ثم حاول مرة أخرى."
  }));
  return true;
});

async function openNoorPreview(rows) {
  if (!Array.isArray(rows) || !rows.length || rows.length > 1000 ||
      rows.some((row) => !row || typeof row.id !== "string" || !/^\d{1,30}$/.test(row.id) ||
        !Number.isFinite(row.score) || row.score < 0) ||
      new Set(rows.map((row) => row.id)).size !== rows.length) {
    return { error: "تعذر إرسال الدرجات. راجع أرقام الطلاب والدرجات المكررة." };
  }

  const tabs = await chrome.tabs.query({ url: "https://noor.moe.gov.sa/*" });
  const checks = await Promise.all(tabs.map(async (tab) => {
    try {
      const result = await chrome.tabs.sendMessage(tab.id, { type: "NOOR_CHECK_GRADE_TABLE" }, { frameId: 0 });
      return result?.ready ? tab : null;
    } catch {
      return null;
    }
  }));
  const candidates = checks.filter(Boolean);
  if (!candidates.length) return { error: "افتح كشف رصد الدرجات في نور وحدّثه، ثم أعد المحاولة." };
  if (candidates.length > 1) return { error: "أبقِ كشف نور المطلوب وحده مفتوحًا، ثم أعد المحاولة." };

  const [tab] = candidates;
  const result = await chrome.tabs.sendMessage(tab.id, { type: "NOOR_STAGE_WARAQA_GRADES", rows }, { frameId: 0 });
  if (!result?.ready) return { error: "تغيّر كشف الدرجات في نور. افتح الكشف المطلوب وأعد المحاولة." };
  await chrome.tabs.update(tab.id, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true });
  return { ok: true };
}
