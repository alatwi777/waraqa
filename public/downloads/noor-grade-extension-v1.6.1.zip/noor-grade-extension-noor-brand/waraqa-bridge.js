window.addEventListener("message", async (event) => {
  const request = event.data;
  if (event.source !== window || event.origin !== location.origin ||
      request?.type !== "WARAQA_NOOR_PREVIEW" || typeof request.id !== "string") return;

  let result;
  try {
    result = await chrome.runtime.sendMessage({ ...request, type: "NOOR_PREVIEW_FROM_WARAQA" });
  } catch {
    result = { error: "تعذر الاتصال بإضافة نور. حدّث تبويبي ورقة ونور." };
  }
  window.postMessage({ type: "WARAQA_NOOR_REPLY", id: request.id, result }, location.origin);
});
